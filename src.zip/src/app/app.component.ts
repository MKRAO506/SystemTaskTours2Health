import { Component } from '@angular/core';

import { Platform, NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  menuItems: any = [
    { Name: 'Profile', Icon: 'person-circle' },
    { Name: 'Shop by category', Icon: 'basket' },
    { Name: 'Recent Views', Icon: 'aperture' },
    { Name: 'Saved items', Icon: 'save' },
    { Name: 'My Orders', Icon: 'reorder-four' },
    { Name: 'Payment Method', Icon: 'wallet' },
    { Name: 'Delivery info', Icon: 'radio' },
    { Name: 'purchase History', Icon: 'clipboard' },
    { Name: 'Your Notifications inbox', Icon: 'notifications' },
    { Name: 'Change language(English)', Icon: 'globe' },
    { Name: 'Customer Support', Icon: 'people' },
    { Name: 'Settings', Icon: 'settings' }
  ]
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private router: Router,
    public navCtrl: NavController,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.platform.backButton.subscribe(() => {
        if (this.router.url === '/login') {
          navigator['app'].exitApp();
        }
        if (this.router.url === '/mainmenu' || this.router.url === '/home' || this.router.url === '/tabs/tab3' || this.router.url === '/tabs/tab4' || this.router.url === '/tabs/tab5') {
          navigator['app'].exitApp();
        }
      });
    });
  }
  ItemClick(item: any) {
    if (item == 'Your Notifications inbox') {
      this.navCtrl.navigateForward('/notification');
    }
  }
}
