import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  UserInfo: any = {};
  constructor(
    public navCtrl: NavController,
  ) { }

  ngOnInit() {
    this.UserInfo.USERNAME = 'nivish1234';
    this.UserInfo.PASSWORD = '1234567890';
  }
  signup() {
    this.navCtrl.navigateForward('/signup');
  }
  ForgotPassword() {
    this.navCtrl.navigateForward('/passwordreset');
  }
  SignIn() {
    this.navCtrl.navigateRoot('/mainmenu');
  }
}
