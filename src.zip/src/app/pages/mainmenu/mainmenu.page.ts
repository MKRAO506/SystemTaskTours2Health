import { Component, OnInit } from '@angular/core';
import { ListOfDefine } from 'src/app/definingRequests/ListOfDefine';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-mainmenu',
  templateUrl: './mainmenu.page.html',
  styleUrls: ['./mainmenu.page.scss'],
})
export class MainmenuPage implements OnInit {
  WeekDates: any = [
    { Name: 'Vegetables', Cost: 100.00, Url: 'https://cdn.britannica.com/17/196817-050-6A15DAC3/vegetables.jpg' },
    { Name: 'Fruits', Cost: 100.00, Url: 'https://cdn.britannica.com/17/196817-050-6A15DAC3/vegetables.jpg' },
    { Name: 'Dairy', Cost: 100.00, Url: 'https://cdn.britannica.com/17/196817-050-6A15DAC3/vegetables.jpg' },
    { Name: 'Others', Cost: 100.00, Url: 'https://cdn.britannica.com/17/196817-050-6A15DAC3/vegetables.jpg' }
  ];
  TodayDeals: any = [
    { Name: 'Farm Fresh Tomatos', Cost: 100.00, Url: 'https://ychef.files.bbci.co.uk/976x549/p04w46sp.jpg' },
    { Name: 'Farm Fresh Bananas', Cost: 120.00, Url: 'https://img.webmd.com/dtmcms/live/webmd/consumer_assets/site_images/article_thumbnails/slideshows/powerhouse_vegetables_slideshow/650x350_powerhouse_vegetables_slideshow.jpg' },
    { Name: 'Farm Fresh Apples', Cost: 150.50, Url: 'https://cdn.vox-cdn.com/thumbor/1lkbiwsmSbovu-HAyjWeZTcGQo8=/0x0:1920x1280/1200x800/filters:focal(807x487:1113x793)/cdn.vox-cdn.com/uploads/chorus_image/image/57340051/apples_2811968_1920.0.jpg' },
    { Name: 'Farm Fresh Grapes', Cost: 160.00, Url: 'https://cdn.vox-cdn.com/thumbor/1lkbiwsmSbovu-HAyjWeZTcGQo8=/0x0:1920x1280/1200x800/filters:focal(807x487:1113x793)/cdn.vox-cdn.com/uploads/chorus_image/image/57340051/apples_2811968_1920.0.jpg' }
  ];
  searchItem: any;
  SearchList: any = [];
  constructor(
    public navCtrl: NavController,
    public listOfDefine: ListOfDefine,
  ) { }

  ngOnInit() {
  }
  selectedItem(item: any) {

    this.listOfDefine.SelectedItem = item;
    this.navCtrl.navigateForward('/product-details');
  }
  AddToCart() {
    this.navCtrl.navigateForward('/cart');
  }
  searchForItem() {
    if (this.searchItem.length == 0) {
      this.SearchList = [];
      return false;
    }
    this.SearchList = this.filterItems(this.TodayDeals, this.searchItem);
  }
  filterItems(items: any, searchTerm: string) {
    return items.filter((item: any) => {
      return item.Name.valueOf().toLowerCase().indexOf(searchTerm.valueOf().toLowerCase()) > -1;
    });
  }
}
