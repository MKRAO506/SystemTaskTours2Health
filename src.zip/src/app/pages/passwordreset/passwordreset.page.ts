import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-passwordreset',
  templateUrl: './passwordreset.page.html',
  styleUrls: ['./passwordreset.page.scss'],
})
export class PasswordresetPage implements OnInit {
  UserInfo: any = {};
  constructor(
    public toastController: ToastController
  ) { }

  ngOnInit() {
    this.UserInfo.USERNAME = 'atnivesh@gmail.com';
  }
  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Password reset code sent to your mail',
      color: 'dark',
      duration: 2000
    });
    toast.present();
  }

}
