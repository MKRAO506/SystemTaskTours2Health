import { Component, OnInit } from '@angular/core';
import { ListOfDefine } from 'src/app/definingRequests/ListOfDefine';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.page.html',
  styleUrls: ['./product-details.page.scss'],
})
export class ProductDetailsPage implements OnInit {
  constructor(
    public navCtrl: NavController,
    public listOfDefine: ListOfDefine,
  ) { }

  ngOnInit() {
  }
  AddToCart() {
    this.navCtrl.navigateForward('/cart');
  }
}
