import { Component, OnInit } from '@angular/core';
import { AlertController, NavController, ActionSheetController } from '@ionic/angular';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  UserInfo: any = {}
  error: boolean;
  timer: any = '';
  maxTime: number;
  hidevalue: boolean;
  constructor(
    public navCtrl: NavController,
    public actionSheetController: ActionSheetController,
    public alertController: AlertController
  ) { }

  ngOnInit() {
    this.UserInfo.USERNAME = 'Nivesh123';
    this.UserInfo.EMAIL = 'atnivesh@gmail.com';
    this.UserInfo.PASSWORD = '123456789';
    this.UserInfo.MOBILE = 8281624737;
  }
  async presentAlertConfirm() {
    this.error = true;
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Verify your number',
      subHeader: '4 digit code sent to +91 8281 6247 37',
      inputs: [
        {
          name: 'teliphone',
          type: 'tel',
        }
      ],
      buttons: [
        {
          text: 'Resend' + this.timer,
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
            this.timer = 30;
            this.StartTimer()
            return false;
          }
        }, {
          text: 'VERIFY',
          handler: () => {
            console.log('Confirm Okay');
            if (this.error) {
              this.error = false;
              alert.message = "The OTP yo've entered is incorrect. Please try again"
              alert.header = "Incorrect OTP"
              alert.subHeader = ""
              return false;
            }
            this.presentActionSheet();
          }
        }
      ]
    });

    await alert.present();
  }
  StartTimer() {
    var TimeOut = setTimeout(x => {
      if (this.timer == 0) {

      } else {
        this.timer = this.timer - 1
        this.StartTimer();
      }
    }, 1000);
  }
  login() {
    this.navCtrl.back();
  }
  async presentActionSheet() {
    const actionSheet = await this.actionSheetController.create({
      header: 'Cngratulations!',
      subHeader:'Your mobile number verified successfully! You can now continue using The Organic Planters App',
      cssClass: 'my-custom-class',
      buttons: [
        {
          text: 'LATER',
          role: 'destructive',
          handler: () => {
            console.log('Delete clicked');
          }
        }, {
          text: 'SIGN IN',
          handler: () => {
            console.log('Share clicked');
            this.navCtrl.navigateRoot('/mainmenu');
          }
        },
      ]
    });
    await actionSheet.present();
  }
}
